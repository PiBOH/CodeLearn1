import { supabase } from '../supabaseClient';

/**
 * Salva o aggiorna i progressi dell'utente su Supabase
 * @param username Il nickname dell'utente attuale
 * @param progressData L'oggetto contenente i punti, livelli completati, ecc.
 */
export async function saveUserProgress(username: string, progressData: object) {
  // Sicurezza: Evitiamo di inviare dati se l'utente usa i suffissi locali
  if (username.endsWith('-LOCAL') || username.endsWith('-GUEST')) {
    console.log('Utente locale/ospite: salvataggio su Supabase saltato.');
    return;
  }

  const currentVersion = '1.1.2a-1';
  const platform = window.navigator.userAgent.includes('Android') ? 'Android APK' : 'Web (Vercel)';
  const deviceInfo = window.navigator.userAgent;

  // L'operazione "upsert" inserisce il record se non esiste, o lo aggiorna se l'username c'è già
  const { error } = await supabase
    .from('users')
    .upsert(
      {
        username: username,
        last_version: currentVersion,
        platform: platform,
        device_info: deviceInfo,
        progress_data: progressData,
      },
      { onConflict: 'username' }
    );

  if (error) {
    console.error('Errore durante il salvataggio cloud su Supabase:', error.message);
  } else {
    console.log('Progressi sincronizzati su Supabase con successo!');
  }
}
