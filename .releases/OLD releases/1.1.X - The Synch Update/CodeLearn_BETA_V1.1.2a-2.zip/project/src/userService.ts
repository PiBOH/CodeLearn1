import { supabase } from '../supabaseClient';

/**
 * Salva o aggiorna i progressi dell'utente su Supabase
 * @param username Il nickname dell'utente attuale
 * @param progressData L'oggetto contenente i punti, livelli completati, ecc.
 */
export async function saveUserProgress(username: string, progressData: object) {
  // Sicurezza: Evitiamo di inviare dati se l'utente usa i tuoi suffissi locali
  if (username.endsWith('-LOCAL') || username.endsWith('-GUEST')) {
    console.log('Utente locale/ospite: salvataggio su Supabase saltato.');
    return;
  }

  // Estraiamo la versione e la piattaforma (puoi renderle dinamiche basandoti sulle tue variabili)
  const currentVersion = "1.1.2a-1"; 
  const platform = window.navigator.userAgent.includes('Android') ? 'Android APK' : 'Web (Vercel)';
  const deviceInfo = window.navigator.userAgent;

  // L'operazione "upsert" inserisce il record se non esiste, o lo aggiorna se l'username c'è già
  const { error } = await supabase
    .from('users')
    .upsert(
      {
        username: username,
        last_version: currentVersion,
        platform: platform,
        device_info: deviceInfo,
        progress_data: progressData, // Supabase salverà questo oggetto JSON nel campo jsonb automaticamente
      },
      { onConflict: 'username' } // Specifica che il controllo di duplicato si fa sulla colonna username
    );

  if (error) {
    console.error('Errore durante il salvataggio cloud su Supabase:', error.message);
  } else {
    console.log('Progressi sincronizzati su Supabase con successo!');
  }
}