# Guida Build APK su Windows — CodeLearn BETA V1.1.1a-4

## ⚠️ Problema comune: `.\gradlew` non riconosciuto in PowerShell

Se vedi questo errore:
```
.\gradlew : The term '.\gradlew' is not recognized...
```
Hai due soluzioni. Scegli quella più comoda:

---

## ✅ SOLUZIONE A — Usare `gradlew.bat` invece di `.\gradlew`

Su Windows PowerShell devi usare **`gradlew.bat`** al posto di `./gradlew`:

```powershell
npm install
npm run build
npx cap sync android
cd android
.\gradlew.bat assembleDebug
```

Questo è tutto. `gradlew.bat` è il wrapper nativo per Windows.

---

## ✅ SOLUZIONE B — Rigenera il wrapper Gradle (se gradlew.bat non basta)

Se anche `gradlew.bat` non funziona, significa che manca `gradle-wrapper.jar`.
Rigenera il wrapper con questo script dalla root del progetto:

```powershell
# dalla root del progetto (non dalla cartella android)
.\RIGENERA_WRAPPER.ps1
```

Oppure manualmente:
```powershell
cd android
gradle wrapper --gradle-version 8.11.1
cd ..
```

Poi torna al flusso normale:
```powershell
.\gradlew.bat assembleDebug
```

---

## 📋 Flusso completo consigliato su Windows

```powershell
# 1. Dalla ROOT del progetto
npm install
npm run build
npx cap sync android

# 2. Entra nella cartella android
cd android

# 3. Build APK  ← usa gradlew.bat, NON .\gradlew
.\gradlew.bat assembleDebug
```

**Output APK:** `android\app\build\outputs\apk\debug\app-debug.apk`

---

## 🔧 Prerequisiti

| Strumento | Versione | Download |
|-----------|----------|----------|
| Node.js   | 18+      | https://nodejs.org |
| Java JDK  | 17       | https://adoptium.net |
| Android Studio | Latest | https://developer.android.com/studio |
| Android SDK | 34 | Tramite SDK Manager in Android Studio |

### Variabili d'ambiente richieste (PATH)
Aggiungi queste cartelle al PATH di Windows:
- `%LOCALAPPDATA%\Android\Sdk\platform-tools`
- `%JAVA_HOME%\bin` (dove JAVA_HOME punta al JDK 17)

---

## 🚀 Build Release (APK firmato)

In Android Studio: **Build → Generate Signed Bundle / APK → APK**

Oppure da linea di comando:
```powershell
.\gradlew.bat assembleRelease
```
