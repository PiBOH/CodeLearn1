// ─────────────────────────────────────────────────────────────────────────────
// AppContext.tsx — Stato globale + sincronizzazione cloud ibrida
// CodeLearn v1.1.0a - The Synch Update
// ─────────────────────────────────────────────────────────────────────────────

import {
  createContext, useContext, useState, useCallback,
  useEffect, useRef, type ReactNode,
} from 'react';
import { detectDevice } from '../lib/deviceInfo';
import {
  createCloudUser, updateCloudUser, getUserByUsername,
  isSupabaseConfigured,
} from '../lib/supabase';

// ── Costanti ──────────────────────────────────────────────────────────────────

export const APP_VERSION      = '1.1.0a-2';
export const APP_VERSION_FULL = '1.1.0a-2 - The Synch Update';

const LS_PROGRESS    = 'codelearn-progress';
const LS_ONBOARDING  = 'codelearn-onboarding';
const LS_USERNAME    = 'codelearn-username';
const LS_CLOUD_ID    = 'codelearn-cloud-id';
const LS_GUEST_MODE  = 'codelearn-guest-mode';
const LS_LAST_ACTIVE = 'codelearn-last-active';
const LS_PENDING     = 'codelearn-pending-badges';

// ── Tipi ──────────────────────────────────────────────────────────────────────

export interface UserProgress {
  completedLessons: string[];
  xp: number;
  level: number;
  streak: number;
  badges: string[];
  courseProgress: Record<string, number>;
  startedCourses: string[];
}

export type SyncStatus = 'idle' | 'syncing' | 'synced' | 'error' | 'offline';

const defaultProgress: UserProgress = {
  completedLessons: [],
  xp: 0, level: 1, streak: 0,
  badges: [], courseProgress: {}, startedCourses: [],
};

// ── Helpers streak ────────────────────────────────────────────────────────────

function todayStr() { return new Date().toISOString().slice(0, 10); }

function daysBetween(a: string, b: string) {
  return Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86_400_000);
}

function computeStreak(
  current: number, lastActive: string | null,
): { streak: number; lastActive: string } {
  const today = todayStr();
  if (!lastActive)          return { streak: 1, lastActive: today };
  if (lastActive === today) return { streak: current, lastActive: today };
  const diff = daysBetween(lastActive, today);
  if (diff === 1)           return { streak: current + 1, lastActive: today };
  return { streak: 1, lastActive: today };
}

// ── Badge helper ──────────────────────────────────────────────────────────────

function evaluateBadges(
  completed: number, level: number, streak: number,
  startedCourses: number, existing: string[],
): string[] {
  const add = (id: string) => !existing.includes(id) && existing.push(id);
  if (completed >= 1)      add('first-step');
  if (completed >= 5)      add('explorer');
  if (completed >= 10)     add('coder');
  if (completed >= 20)     add('rocket');
  if (level >= 5)          add('master');
  if (level >= 10)         add('crown');
  if (streak >= 7)         add('streak-7');
  if (startedCourses >= 3) add('polyglot');
  return existing;
}

// ── Guest utils ───────────────────────────────────────────────────────────────

export function isGuestUsername(name: string): boolean {
  return name.toUpperCase().endsWith('-TEMP');
}

function clearGuestData() {
  [LS_PROGRESS, LS_USERNAME, LS_CLOUD_ID, LS_GUEST_MODE,
    LS_LAST_ACTIVE, LS_PENDING, LS_ONBOARDING].forEach(k =>
    localStorage.removeItem(k));
}

// ── Tipo context ──────────────────────────────────────────────────────────────

interface AppContextType {
  progress: UserProgress;
  username: string;
  onboardingDone: boolean;
  isGuestMode: boolean;
  cloudUserId: string | null;
  syncStatus: SyncStatus;

  completeLesson: (
    lessonId: string, courseId: string, xp: number,
    onNewBadges?: (ids: string[]) => void,
  ) => void;
  hasCompleted:     (lessonId: string) => boolean;
  getCourseProgress:(courseId: string, totalLessons: number) => number;
  unlockBadge:      (badgeId: string) => void;

  setOnboardingDone:(v: boolean) => void;
  setUsername:      (v: string) => void;
  loginAs:          (username: string, forceNew?: boolean) => Promise<void>;
}

// ── Context ───────────────────────────────────────────────────────────────────

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {

  // Pulizia automatica all'avvio se la sessione precedente era guest
  useEffect(() => {
    const wasGuest = localStorage.getItem(LS_GUEST_MODE) === 'true';
    if (wasGuest) { clearGuestData(); window.location.reload(); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── State ─────────────────────────────────────────────────────────────────

  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem(LS_PROGRESS);
    const base  = saved ? (JSON.parse(saved) as UserProgress) : defaultProgress;
    if (!base.startedCourses) base.startedCourses = [];
    return base;
  });

  const [onboardingDone, setOnboardingDoneState] = useState(
    () => localStorage.getItem(LS_ONBOARDING) === 'true',
  );
  const [username, setUsernameState] = useState(
    () => localStorage.getItem(LS_USERNAME) ?? '',
  );
  const [isGuestMode,  setIsGuestMode]  = useState(false);
  const [cloudUserId, setCloudUserId] = useState<string | null>(
    () => localStorage.getItem(LS_CLOUD_ID),
  );
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('idle');

  // refs anti-stale-closure
  const isGuestRef = useRef(isGuestMode);
  const cloudIdRef = useRef(cloudUserId);
  const syncTimer  = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { isGuestRef.current = isGuestMode; }, [isGuestMode]);
  useEffect(() => { cloudIdRef.current = cloudUserId;  }, [cloudUserId]);

  // Pulizia guest su chiusura tab/WebView
  useEffect(() => {
    const onUnload = () => { if (isGuestRef.current) clearGuestData(); };
    window.addEventListener('beforeunload', onUnload);
    return () => window.removeEventListener('beforeunload', onUnload);
  }, []);

  // ── Cloud sync debounced ──────────────────────────────────────────────────

  const syncToCloud = useCallback(async (p: UserProgress) => {
    if (isGuestRef.current || !cloudIdRef.current || !isSupabaseConfigured()) return;
    setSyncStatus('syncing');
    try {
      const { platform, deviceDetails } = detectDevice();
      await updateCloudUser(cloudIdRef.current, {
        last_version: APP_VERSION, platform,
        device_info: deviceDetails, progress_data: p,
      });
      setSyncStatus('synced');
    } catch (err) {
      console.warn('[CodeLearn] sync error:', err);
      setSyncStatus('error');
    }
  }, []);

  const debouncedSync = useCallback((p: UserProgress) => {
    if (syncTimer.current) clearTimeout(syncTimer.current);
    syncTimer.current = setTimeout(() => syncToCloud(p), 2000);
  }, [syncToCloud]);

  // ── loginAs (chiamato da Onboarding) ─────────────────────────────────────

  const loginAs = useCallback(async (name: string, forceNew = false) => {
    const trimmed = name.trim();
    if (!trimmed) return;

    // ── Modalità Ospite ──────────────────────────────────────────────────
    if (isGuestUsername(trimmed)) {
      setIsGuestMode(true);
      isGuestRef.current = true;
      localStorage.setItem(LS_GUEST_MODE, 'true');
      setUsernameState(trimmed);
      localStorage.setItem(LS_USERNAME, trimmed);
      setSyncStatus('offline');
      return;
    }

    // ── No Supabase configurato: solo locale ─────────────────────────────
    if (!isSupabaseConfigured()) {
      setUsernameState(trimmed);
      localStorage.setItem(LS_USERNAME, trimmed);
      setSyncStatus('offline');
      return;
    }

    // ── Utente cloud ─────────────────────────────────────────────────────
    setSyncStatus('syncing');
    try {
      const { platform, deviceDetails } = detectDevice();

      if (!forceNew) {
        const existing = await getUserByUsername(trimmed);
        if (existing) {
          // Carica progressi dal cloud
          const cp: UserProgress = {
            ...defaultProgress, ...(existing.progress_data ?? {}),
          };
          if (!cp.startedCourses) cp.startedCourses = [];
          setProgress(cp);
          localStorage.setItem(LS_PROGRESS, JSON.stringify(cp));

          setCloudUserId(existing.id);
          cloudIdRef.current = existing.id;
          localStorage.setItem(LS_CLOUD_ID, existing.id);
          setUsernameState(trimmed);
          localStorage.setItem(LS_USERNAME, trimmed);

          await updateCloudUser(existing.id, {
            last_version: APP_VERSION, platform, device_info: deviceDetails,
          });
          setSyncStatus('synced');
          return;
        }
      }

      // Crea nuovo utente
      const created = await createCloudUser({
        username: trimmed, last_version: APP_VERSION,
        platform, device_info: deviceDetails,
        progress_data: progress,
      });
      setCloudUserId(created.id);
      cloudIdRef.current = created.id;
      localStorage.setItem(LS_CLOUD_ID, created.id);
      setUsernameState(trimmed);
      localStorage.setItem(LS_USERNAME, trimmed);
      setSyncStatus('synced');
    } catch (err) {
      console.warn('[CodeLearn] loginAs error:', err);
      setUsernameState(trimmed);
      localStorage.setItem(LS_USERNAME, trimmed);
      setSyncStatus('error');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [progress]);

  // ── setUsername (compat) ──────────────────────────────────────────────────

  const setUsername = useCallback((v: string) => {
    setUsernameState(v);
    localStorage.setItem(LS_USERNAME, v);
  }, []);

  // ── unlockBadge ───────────────────────────────────────────────────────────

  const unlockBadge = useCallback((badgeId: string) => {
    setProgress(prev => {
      if (prev.badges.includes(badgeId)) return prev;
      const next = { ...prev, badges: [...prev.badges, badgeId] };
      localStorage.setItem(LS_PROGRESS, JSON.stringify(next));
      debouncedSync(next);
      return next;
    });
  }, [debouncedSync]);

  // ── completeLesson ────────────────────────────────────────────────────────

  const completeLesson = useCallback((
    lessonId: string, courseId: string, xp: number,
    onNewBadges?: (ids: string[]) => void,
  ) => {
    setProgress(prev => {
      if (prev.completedLessons.includes(lessonId)) return prev;

      const newCompleted = [...prev.completedLessons, lessonId];
      const newXp        = prev.xp + xp;
      const newLevel     = Math.floor(newXp / 100) + 1;
      const newCP        = { ...prev.courseProgress };
      newCP[courseId]    = (newCP[courseId] ?? 0) + 1;
      const newStarted   = prev.startedCourses.includes(courseId)
        ? prev.startedCourses : [...prev.startedCourses, courseId];

      const lastActive = localStorage.getItem(LS_LAST_ACTIVE);
      const { streak: newStreak, lastActive: nla } =
        computeStreak(prev.streak, lastActive);
      localStorage.setItem(LS_LAST_ACTIVE, nla);

      const newBadges = evaluateBadges(
        newCompleted.length, newLevel, newStreak, newStarted.length,
        [...prev.badges],
      );
      const justUnlocked = newBadges.filter(id => !prev.badges.includes(id));
      if (justUnlocked.length > 0 && onNewBadges) {
        localStorage.setItem(LS_PENDING, JSON.stringify(justUnlocked));
      }

      const next: UserProgress = {
        ...prev, completedLessons: newCompleted,
        xp: newXp, level: newLevel, streak: newStreak,
        badges: newBadges, courseProgress: newCP, startedCourses: newStarted,
      };
      localStorage.setItem(LS_PROGRESS, JSON.stringify(next));
      debouncedSync(next);
      return next;
    });

    setTimeout(() => {
      const pending = localStorage.getItem(LS_PENDING);
      if (pending) {
        localStorage.removeItem(LS_PENDING);
        const ids: string[] = JSON.parse(pending);
        if (ids.length > 0) onNewBadges?.(ids);
      }
    }, 350);
  }, [debouncedSync]);

  // ── Helpers ───────────────────────────────────────────────────────────────

  const hasCompleted = useCallback(
    (lid: string) => progress.completedLessons.includes(lid),
    [progress.completedLessons],
  );
  const getCourseProgress = useCallback(
    (cid: string, total: number) =>
      Math.round(((progress.courseProgress[cid] ?? 0) / total) * 100),
    [progress.courseProgress],
  );
  const setOnboardingDone = useCallback((v: boolean) => {
    setOnboardingDoneState(v);
    localStorage.setItem(LS_ONBOARDING, String(v));
  }, []);

  // ── Provider ──────────────────────────────────────────────────────────────

  return (
    <AppContext.Provider value={{
      progress, username, onboardingDone,
      isGuestMode, cloudUserId, syncStatus,
      completeLesson, hasCompleted, getCourseProgress, unlockBadge,
      setOnboardingDone, setUsername, loginAs,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp deve essere usato dentro AppProvider');
  return ctx;
}
