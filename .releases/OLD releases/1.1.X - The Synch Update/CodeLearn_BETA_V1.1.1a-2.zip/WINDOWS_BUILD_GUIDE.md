# Guida Build APK su Windows — CodeLearn BETA V1.1.1a-2

## Prerequisiti
1. **Node.js 18+** — https://nodejs.org
2. **Java JDK 17** — https://adoptium.net
3. **Android Studio** — https://developer.android.com/studio
   - Installa Android SDK 34 (in SDK Manager)
   - Installa Android SDK Build-Tools 34

## Variabili d'ambiente Windows
Aggiungi a PATH:
- `C:\Program Files\Android\Android Studio\jbr\bin`
- `%LOCALAPPDATA%\Android\Sdk\platform-tools`

## Build

Apri PowerShell nella cartella del progetto:

```powershell
npm install
npm run build
npx cap sync android
npx cap open android
```

In Android Studio: **Build → Build APK(s)**

## Output
`android\app\build\outputs\apk\debug\app-debug.apk`
