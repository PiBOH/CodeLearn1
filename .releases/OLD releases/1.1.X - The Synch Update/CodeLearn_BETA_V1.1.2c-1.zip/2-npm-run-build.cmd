npm run build && pause && start .\3-npx-cap-sync-android.cmd\
