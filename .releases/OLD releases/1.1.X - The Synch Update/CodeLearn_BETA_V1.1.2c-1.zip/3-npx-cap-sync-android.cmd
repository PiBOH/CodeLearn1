npx cap sync android && start .\4-cd-android+gradlew-assembleDebug.cmd\
