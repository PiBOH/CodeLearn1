npm install && start .\2-npm-run-build.cmd\
