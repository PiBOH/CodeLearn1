cd android && ./gradlew assembleDebug && pause && start .\5-remove-npm.cmd\
