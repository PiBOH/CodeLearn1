# ─────────────────────────────────────────────────────────────────────────────
# FIX_GRADLE.ps1 — Ripara gradle-wrapper.jar copiandolo da node_modules
# CodeLearn — Esegui dalla ROOT del progetto dopo "npm install"
#
# Uso:
#   1. npm install          (nella root del progetto)
#   2. .\FIX_GRADLE.ps1    (nella root del progetto)
#   3. npm run build
#   4. npx cap sync android
#   5. cd android
#   6. .\gradlew.bat assembleDebug
# ─────────────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "=== CodeLearn — Fix Gradle Wrapper ===" -ForegroundColor Cyan
Write-Host ""

$root       = $PSScriptRoot
$jarDest    = Join-Path $root "android\gradle\wrapper\gradle-wrapper.jar"
$jarSrc     = Join-Path $root "node_modules\@capacitor\android\android\gradle\wrapper\gradle-wrapper.jar"

# Controlla che npm install sia stato eseguito
if (-not (Test-Path $jarSrc)) {
    Write-Host "ERRORE: gradle-wrapper.jar non trovato in node_modules." -ForegroundColor Red
    Write-Host "Esegui prima: npm install" -ForegroundColor Yellow
    exit 1
}

# Copia il jar vero
Write-Host "Copio gradle-wrapper.jar da node_modules..." -ForegroundColor Gray
Copy-Item -Path $jarSrc -Destination $jarDest -Force

$size = (Get-Item $jarDest).Length
Write-Host "OK — gradle-wrapper.jar copiato ($([math]::Round($size/1KB)) KB)" -ForegroundColor Green
Write-Host ""
Write-Host "Ora puoi buildare con:" -ForegroundColor Cyan
Write-Host "  npm run build" -ForegroundColor White
Write-Host "  npx cap sync android" -ForegroundColor White
Write-Host "  cd android" -ForegroundColor White
Write-Host "  .\gradlew.bat assembleDebug" -ForegroundColor White
Write-Host ""
