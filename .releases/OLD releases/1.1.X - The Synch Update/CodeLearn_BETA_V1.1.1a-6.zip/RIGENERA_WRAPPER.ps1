# RIGENERA_WRAPPER.ps1
# Esegui questo script UNA VOLTA dalla root del progetto se gradlew non funziona.
# Richiede Gradle installato globalmente oppure Android Studio.

Write-Host "=== CodeLearn - Rigenera Gradle Wrapper ===" -ForegroundColor Cyan

$androidDir = Join-Path $PSScriptRoot "android"

# Controlla se gradle è disponibile globalmente
if (Get-Command gradle -ErrorAction SilentlyContinue) {
    Write-Host "Gradle trovato. Rigenero il wrapper..." -ForegroundColor Green
    Push-Location $androidDir
    gradle wrapper --gradle-version 8.11.1
    Pop-Location
    Write-Host "Wrapper rigenerato! Ora puoi usare .\gradlew assembleDebug" -ForegroundColor Green
}
# Controlla Android Studio (percorso default)
elseif (Test-Path "C:\Program Files\Android\Android Studio\bin\studio64.exe") {
    Write-Host "Gradle non trovato nel PATH." -ForegroundColor Yellow
    Write-Host "Soluzione: apri Android Studio, poi Build > Rebuild Project." -ForegroundColor Yellow
    Write-Host "Android Studio rigenerera' il wrapper automaticamente." -ForegroundColor Yellow
}
else {
    Write-Host "ERRORE: Gradle non trovato nel PATH." -ForegroundColor Red
    Write-Host ""
    Write-Host "Soluzioni:" -ForegroundColor Yellow
    Write-Host "  1. Installa Gradle: https://gradle.org/install/" -ForegroundColor White
    Write-Host "     poi riesegui questo script" -ForegroundColor White
    Write-Host "  2. Oppure esegui manualmente:" -ForegroundColor White
    Write-Host "     cd android" -ForegroundColor Cyan
    Write-Host "     gradle wrapper --gradle-version 8.11.1" -ForegroundColor Cyan
    Write-Host "  3. Oppure usa Android Studio: Build > Rebuild Project" -ForegroundColor White
}
